//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by T1aluno10 on 24/04/18.
//  Copyright © 2018 T1aluno10. All rights reserved.
//

import UIKit
class MapViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("MapViewController loaded its view.")
    }

}
