//
//  Photo+CoreDataClass.swift
//  Photorama
//
//  Created by Christian Keur on 9/5/16.
//  Copyright © 2016 Big Nerd Ranch. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


public class Photo: NSManagedObject {

}
